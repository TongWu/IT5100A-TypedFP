import Section3Support

-- TODO: Question 10: write the full program.

main :: IO ()
main = putStrLn "Hello World!"

