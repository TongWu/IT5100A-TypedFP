-- TODO: Question 1: define the Rotation ADT
data Rotation 

-- TODO: Question 2: define the 'toRotations' function
toRotations = undefined

-- TODO: Question 3: define the 'unlockSequence' function
unlockSequence = undefined

-- TODO: Question 4: define the 'willOpen' function
willOpen = undefined

