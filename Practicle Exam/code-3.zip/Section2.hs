import Section2Support
-- feel free to use 'guard' from 'Control.Monad'
import Control.Monad 
-- import other things too if you want

-- TODO: Question 5: define the 'update' function
update = undefined

-- TODO: Question 6: define the 'deductUserBalance' function
deductUserBalance = undefined

-- TODO: Question 7: define the 'deductProductQuantity' function
deductProductQuantity = undefined

-- TODO: Question 8: define the 'addProductToUser' function
addProductToUser = undefined

-- TODO: Question 9: define the 'userPurchaseProduct' function
userPurchaseProduct = undefined

