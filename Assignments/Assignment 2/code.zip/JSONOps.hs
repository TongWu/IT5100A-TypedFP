module JSONOps where
import JSON
import TransformOn

instance TransformOn JSON JSON where
  -- TODO: Question 1

addAll :: TransformOn JSON a => Int -> a -> a
addAll = undefined -- TODO: Question 2

negateAll :: TransformOn JSON a => a -> a
negateAll = undefined -- TODO: Question 2

filterNull :: TransformOn JSON a => a -> a
filterNull = undefined -- TODO: Question 2

instance TransformOn String JSON where
  -- TODO: Question 3

-- Example function for question 3
reverseAllStrings :: TransformOn String a => a -> a
reverseAllStrings = transformOn (reverse :: String -> String)

getN :: JSON -> Maybe Int
getN = undefined -- TODO: Question 4

queryKey :: String -> JSON -> Maybe JSON
queryKey = undefined -- TODO: Question 5

getScore :: String -> JSON -> Maybe Int
getScore = undefined

