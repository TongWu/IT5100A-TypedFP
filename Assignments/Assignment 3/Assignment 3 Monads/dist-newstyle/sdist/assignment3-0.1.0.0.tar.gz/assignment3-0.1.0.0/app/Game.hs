module Game where

import Data.Game
import Game.Monad
import Text.Read

-- | Repeatedly reads a line from a user until the user
-- enters a valid blank position on the board.
readPosition :: GameM Int
readPosition = undefined

-- | Generates a random blank position on the board
randomPosition :: GameM Int
randomPosition = undefined

-- | Plays a game of monadic tic tac toe
game :: GameM ()
game = undefined
