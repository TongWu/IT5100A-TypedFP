module BankAccounts where

-- TODO: Define the BankAccount ADT.
data BankAccount where 

-- TODO: Define the accountId function. 
accountId = undefined

-- TODO: Define the balance function.
balance = undefined

-- TODO: Define the interest function.
interest = undefined

-- TODO: Define the deposit function.
deposit = undefined

-- TODO: Define the deduct function.
deduct = undefined

-- TODO: Define the transfer function.
transfer = undefined

-- TODO: Define the compound function.
compound = undefined

-- TODO: Define the BSTMap ADT
data BSTMap where

-- TODO: Define the put function.
put = undefined

-- TODO: Define the get function.
get = undefined

-- TODO: Define the in' function.
in' = undefined

-- TODO: Define the values function.
values = undefined

-- TODO: Define the Op ADT
data Op where

-- TODO: Define the processOne function.
processOne = undefined

-- TODO: Define the processAll function.
processAll = undefined

-- TODO: Define the process function.
process = undefined

